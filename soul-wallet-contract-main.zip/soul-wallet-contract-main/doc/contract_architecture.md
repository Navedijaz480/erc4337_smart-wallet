

# Contract architecture

<p align="center">
  <img src="./images//contract_architecture.png" />
</p>