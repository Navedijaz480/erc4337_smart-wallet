module.exports = {
    skipFiles: [
        'dev'
    ],
    configureYulOptimizer: true
  };
  